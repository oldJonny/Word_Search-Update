package com.test;

import java.awt.*;
import java.awt.event.*;
import java.util.HashMap;
import java.util.Map;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

public class JTextFieldDemo1 implements ActionListener {

	// 创建相关变量
	private JFrame jf;
	private JPanel jp;
	private JPanel combop;
	private JTextField jtf1, jtf2, jtf3, jtf4;
	private JButton btn;
	private JTabbedPane jtab;
	private JLabel jl;
	private String search_text;
	private String update_text;

	static final String filepathString = "C:\\Users\\lyzdsb\\Desktop\\dhy\\能效对标输出文档（水泥为例）.docx";
	static final String destpathString = "C:\\Users\\lyzdsb\\Desktop\\能效对标输出文档（水泥为例）（修改后）.docx";

	public String getSearch_text() {
		return search_text;
	}

	public void setSearch_text(String search_text) {
		this.search_text = search_text;
	}

	public String getUpdate_text() {
		return update_text;
	}

	public void setUpdate_text(String update_text) {
		this.update_text = update_text;
	}

	// 构造函数
	public JTextFieldDemo1() {

		jf = new JFrame("Word_search_update");

		Container contentPane = jf.getContentPane();
		contentPane.setLayout(new BorderLayout());

		jp = new JPanel();

		// 4个JTF对象
		jtf1 = new JTextField();
		jtf2 = new JTextField("内容1", 10);
		jtf3 = new JTextField("       -->        ");
		jtf4 = new JTextField("内容2", 10);

		// 点击文本框，默认文字消失
		jtf2.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				jtf2.setText("");
			}

		});

		// 点击文本框，默认文字消失
		jtf4.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				jtf4.setText("");
			}

		});

		// 监听第一个文本框
		jtf2.getDocument().addDocumentListener(new DocumentListener() {
			public void changedUpdate(DocumentEvent e) {
			}

			public void insertUpdate(DocumentEvent e) {
				search_text = jtf2.getText();
				System.out.println("search_text Inserted:" + jtf2.getText());
			}

			public void removeUpdate(DocumentEvent e) {
			}
		});

		// 监听第二个文本框
		jtf4.getDocument().addDocumentListener(new DocumentListener() {
			public void changedUpdate(DocumentEvent e) {
			}

			public void insertUpdate(DocumentEvent e) {
				update_text = jtf4.getText();
				System.out.println("update_text Inserted:" + jtf4.getText());
			}

			public void removeUpdate(DocumentEvent e) {
			}
		});
		jtf3.setEnabled(false);

		jtf2.setFont(new Font("谐体", Font.BOLD | Font.ITALIC, 16));
		jtf4.setFont(new Font("谐体", Font.BOLD | Font.ITALIC, 16));
		// 设置文本的水平对齐方式
		jtf2.setHorizontalAlignment(JTextField.CENTER);
		jtf4.setHorizontalAlignment(JTextField.CENTER);

		// 一个Jbutton对象
		btn = new JButton("确定");
		btn.addActionListener(this);

		jtab = new JTabbedPane(JTabbedPane.TOP); 		
		jtab.add(jp,"测试");
		
		jp.add(jtf1);
		jp.add(jtf2);
		jp.add(jtf3);
		jp.add(jtf4);
		jp.add(btn);
		
		jl = new JLabel("Word文档替换系统");
		combop = new JPanel();
		combop.add(jl);
//		contentPane.setLayout(new BorderLayout());
		contentPane.add(combop,BorderLayout.NORTH);
		contentPane.add(jtab,BorderLayout.CENTER);
		contentPane.add(jp);
		
		//jframe的底层设置
		jf.pack();
		jf.setLocation(400, 200);
		jf.setVisible(true);
		jf.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});
	}

	// 组装result，得到俩个文本框的text
	public static Map<String, String> getResult(String search_text,
			String update_text) {
		Map<String, String> result = new HashMap<String, String>();
		result.put(search_text, update_text);
		return result;
	}

	public static void main(String[] args) {
		JTextFieldDemo1 x = new JTextFieldDemo1();
	}

	// button监听方法
	public void actionPerformed(ActionEvent e) {
		Map<String, String> result = new HashMap<String, String>();
		result = JTextFieldDemo1.getResult(search_text, update_text);
		Word_search_update.replaceAndGenerateWord(filepathString,
				destpathString, result);
	}

}